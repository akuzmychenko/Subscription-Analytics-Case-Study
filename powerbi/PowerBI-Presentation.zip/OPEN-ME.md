# Portable Power BI case study

Dataset: seed-20261023-cd60788c5eca

1. Extract the entire ZIP to a folder on your computer.
2. Open SubscriptionAnalytics.pbip in Power BI Desktop.
3. Click Home > Refresh once to load the embedded scenario into the model.
4. Explore Overview and Retention. You may then save a local PBIX copy.

No DataFolder, repository checkout, internet data source or BAT/CMD launcher is required.
The current CSV bytes are embedded in the model Power Query definitions. The data/ folder is a readable copy for inspection.
Editing those CSV copies does not change this frozen report. Export another project to capture a different scenario.

Unfiltered headline values: 4890 users; 23.19% conversion; EUR 38316.99 collected cash.

The package is a PBIP source project, not a pre-refreshed PBIX. Its first Desktop refresh is required.
Native Power BI Desktop refresh and rendering must be verified locally. case-study.html provides an independent R-generated preview.
